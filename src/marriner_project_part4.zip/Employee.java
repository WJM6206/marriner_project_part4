/*******************************************************************
* Name: William Marriner
* Date: 28 April, 2024
* Assignment: SDC330 Project Part 3
*
* This interface class only has one method that must be implemented.
*/

public  interface Employee {
    public String getName();
    public String getRole();
}